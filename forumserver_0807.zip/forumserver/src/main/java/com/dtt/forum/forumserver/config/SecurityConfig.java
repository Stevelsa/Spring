package com.dtt.forum.forumserver.config;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.dtt.forum.forumserver.service.UserService;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	UserService userService;
	
	@Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userService);
    }
	
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		/*开启登录配置*/
		http.authorizeRequests()
			/*表示访问 /admin下的接口，需要具备 admin 这个角色*/
			.antMatchers("/admin/**").hasRole("超级管理员")
			/*表示剩余的其他接口，登录之后就能访问*/
			.anyRequest().authenticated()
			/*定义登录页面，未登录时，访问一个需要登录之后才能访问的接口，会自动跳转到该页面*/
			.and().formLogin().loginPage("/login_page")
			/*登录处理接口,定义登录时，用户名的 key，默认为 username,用户密码的 key，默认为 password*/
			.loginProcessingUrl("/login").usernameParameter("username").passwordParameter("password")
			/*登录成功的处理器*/
			.successHandler(new AuthenticationSuccessHandler() {
				
				@Override
				public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication)
						throws IOException, ServletException {
					httpServletResponse.setContentType("application/json;charset=utf-8");
					PrintWriter out=httpServletResponse.getWriter();
					out.write("{\"status\":\"success\",\"msg\":\"登录成功\"}");
					out.flush();
					out.close();
				}
			})
			/*登录失败的处理器*/
			.failureHandler(new AuthenticationFailureHandler() {
				
				@Override
				public void onAuthenticationFailure(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException authenticationException)
						throws IOException, ServletException {
					httpServletResponse.setContentType("application/json;charset=utf-8");
					PrintWriter out=httpServletResponse.getWriter();
					out.write("{\"status\":\"error\",\"msg\":\"登录失败\"}");
					out.flush();
					out.close();
				}
			})
			.permitAll()
			.and().logout().permitAll()
			/*表示关闭csrf（Cross-site request forgery）*/
			.and().csrf().disable()
			.exceptionHandling()
			/*没有认证时，在这里处理结果，不要重定向*/
			.accessDeniedHandler(getAccessDeniedHandler());
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception{
		web.ignoring().antMatchers("/index.html");
	}

	@Bean
	AccessDeniedHandler getAccessDeniedHandler() {
		return new AuthenticationAccessDeniedHandler();
	}
}
