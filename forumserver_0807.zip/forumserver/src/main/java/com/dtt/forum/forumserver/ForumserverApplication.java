package com.dtt.forum.forumserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
public class ForumserverApplication {
	public static void main(String[] args) {
		SpringApplication.run(ForumserverApplication.class, args);
	}
}
