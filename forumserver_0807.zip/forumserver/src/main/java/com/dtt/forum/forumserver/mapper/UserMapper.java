package com.dtt.forum.forumserver.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.dtt.forum.forumserver.bean.User;

@Mapper
public interface UserMapper {
	User loadUserByUsername(@Param("username") String username);
	User getUserById(@Param("id") Long id);
	int setUserRole(@Param("id") long id);
}
